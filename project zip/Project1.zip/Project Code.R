library(forecast)
library(tseries)
library(timeSeries)
library(quantmod)


##Setting up a model without any transformation

options("getSymbols.warning4.0"=FALSE)
getSymbols('FDX', from='2013-01-01', to='2018-12-31')
#imports data set from Yahoo Finance
FDXClose=FDX[,4]
#Isolates closing Price

plot(FDXClose, main="Daily Close Price For FDX")
#Plot of closing price 
plot(diff(FDXClose, lag=1), main="Lag 1 Difference of Daily Close Price For FDX")
#plot of the difference of closing prices with lag=1

par(mfrow=c(1,2))
Acf(FDXClose, main="ACF for Closing Prices")
Pacf(FDXClose, main="PACF for Closing Prices")
#creates ACF and PACF for closing prices
#from the graph we can see that the ACF plot is geometric and PACF is significat untill the second lag, this means we will
#use the AR(1) model


##Setting up a model for log transformation

logs=diff(log(FDXClose),lag=1)
logs=logs[!is.na(logs)]
#log transformation with lag=1

par(mfrow=c(1,1))
plot(logs,main="Log Returns Plot")
#plot of the transformed data with lag=1

par(mfrow=c(1,2))
Acf(logs, main="ACF for Log Closing Prices")
Pacf(logs, main="PACF for Log Closing Prices")
#creates ACF and PACF for closing prices
#from the 2 graphs we can see that our arima model will be (7,0,17), d=0 becaude that data is already transformed at lag=1


fit<-arima(logs, order = c(7,0,17))
tsdisplay(residuals(fit), lag.max=40, main="(7,0,17) Model Residuals")
#this is the arima model from the log transformation 
fit


fit2<-arima(FDXClose, order = c(1,1,0))
tsdisplay(residuals(fit2), lag.max=40, main="(1,1,0) Model Residuals")
#this is the arima model from before the log transformation 
fit2

#from the graphs we can see that the arima model from the log transformation has only one lag that passes the CI in the ACF 
#and PACF graph while the original model has 4 lags that pass the CI in the ACF and PACF graphs. We can use this to judge the
#accuracy of the models. Since the model with the log transformation has fewer lags that leave the CI, it is more accurate. 


AIC(fit,k=2)
AIC(fit2,k=2)
#the log based model has a smaller AIC value than the other model. This means it is a better fit


BIC(fit)
BIC(fit2)
#the log based model has a smaller BIC value than the other model. This means it is a better fit
