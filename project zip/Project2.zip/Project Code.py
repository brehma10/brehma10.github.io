#%%
import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
#sns.set_style('darkgrid')
from sklearn.linear_model import LinearRegression
from scipy import stats

# %%
# Imports data as a data frame and accounts for the tab delimiter

data = pd.read_csv('boxoffice.txt', delimiter='\t', header=0)
data.dtypes

# %%
data.head()
data.describe()

# %%
# Assigns dependent and independent variables 

y = data['WorldRevenue']
x = data[['Theaters', 'Budget', 'Rating', 'Genre', 'Sequel', 'Production Method', 'Opening']]

# Converts all of the categorical vairables into bianary varables

x = pd.get_dummies(data=x, drop_first=True)

#%%
# Creates regression model

lin_reg = sm.OLS(y,x).fit()
lin_reg.summary()
#%%
# To check for the equal variance of errors assumption, residuals vs fitted needs to be plotted

def res_v_fitted(model):
    fitted_vals = model.predict()
    resids = model.resid
    resids_standardized = model.get_influence().resid_studentized_internal 

    ax = sns.residplot(x=fitted_vals, y=resids, lowess='Ture', line_kws={'color': 'red'})
    ax.set_title('Residuals vs. Fitted', fontsize = 20)
    ax.set(xlabel = 'Residuals', ylabel= 'Fitted Values')

res_v_fitted(lin_reg)
# From the plot we can conclue the the assumption is not met

# %%
# To check for the normality of errors, we need a qq plot and to preform a shapiro wilk test

def normality_of_errors(model):
    sm.ProbPlot(model.resid).qqplot(line='s');
    plt.title('Q-Q plot');

    sw = stats.shapiro(model.resid)
    print(f'Shapiro-Wilk test - Statistic: {sw[0]:.5f}, P-Value {sw[1]:.5f}')

normality_of_errors(lin_reg)

# The qq plot is inconclusive but via the Shapiro Wilk test's small p=value we can conclude the model fails the test  

# %%
# Since the model has failed both the normality and equal variance of errors assumptions we need to do a box-cox transforamtion 

reg = LinearRegression()
y_trans = stats.boxcox(y, lmbda = .375 )
reg.fit(x,y)

x_constant = sm.add_constant(x)
lin_reg_trans = sm.OLS(y_trans,x_constant).fit()
lin_reg_trans.summary()

# That data has been transformed and a new model has been made 

res_v_fitted(lin_reg_trans)

normality_of_errors(lin_reg_trans)

# Looking at the new plots and the high p-value of the shapiro-wilk test, we can conclude the box-cox transformation was successful 

# %%
# To check if the linearity assumption is met residual vs variable needs to be ploted

def linearity_test(model, y):
    fitted_vals = model.predict()
    resids = model.resid

    fig, ax = plt.subplots(1,2)
    
    sns.regplot(x=fitted_vals, y=y, lowess=True, ax=ax[0], line_kws={'color': 'red'})
    ax[0].set_title('Observed vs. Predicted Values', fontsize=12)
    ax[0].set(xlabel='Predicted', ylabel='Observed')

    sns.regplot(x=fitted_vals, y=resids, lowess=True, ax=ax[1], line_kws={'color': 'red'})
    ax[1].set_title('Residuals vs. Predicted Values', fontsize=12)
    ax[1].set(xlabel='Predicted', ylabel='Residuals')

linearity_test(lin_reg_trans, y_trans)

# Since the fitted lines are not bowed on the ends, we can conclude the linearity assumption is met

# %%
# Now that our model has met all of the regression assumption we can use backwards elemination to get a more accurate model
# To get the following function runs a loop that finds the highest p value and if it's larger than .05 it is eliminated and returns a list 

def backward_elimination(data, target,significance_level = 0.05):
    features = data.columns.tolist()
    while(len(features)>0):
        features_with_constant = sm.add_constant(data[features])
        p_values = sm.OLS(target, features_with_constant).fit().pvalues[1:]
        max_p_value = p_values.max()
        if(max_p_value >= significance_level):
            excluded_feature = p_values.idxmax()
            features.remove(excluded_feature)
        else:
            break 
    return features

x_final = backward_elimination(x, y_trans)

data_dummy = pd.get_dummies(data=x, drop_first=True)

x_final = data_dummy[x_final]

lin_reg_final = sm.OLS(y_trans, x_final).fit()

lin_reg_final.summary()

# The final regression model has a r-squared value of .982

# %%
