lm.data<-read.delim("boxoffice.txt")
attach(lm.data)
summary(lm.data)


MLR<-lm(WorldRevenue~Theaters+Budget+Rating+Genre+Sequel+Production.Method+Opening)
MLR
anova(MLR)
summary(MLR)


## Equal variance meet due to flattness of line in first plot
plot(MLR, 1)


## Normality not meet due to lack of fully diagonal line in second plot and since the p-value is small in the shapiro-wilks test
plot(MLR, 2)
shapiro.test(MLR$residual)


## Since equal variance is not met we must transform y
library(MASS)
trans <- boxcox(WorldRevenue~Theaters+Budget+Rating+Genre+Sequel+Production.Method+Opening, data=lm.data, plotit=F, lambda = seq(-3, 3, by=0.125))
maxyentry <- which.max(trans$y)
trans$x[maxyentry]
##Since lamda is .375 we transform cost with the following formula: (Y^(lm)-1)/lm where lm is .25
lm.data$log.WorldRevenue <- ((WorldRevenue^.375)-1)/.375


MLR2<-lm(lm.data$log.WorldRevenue~Theaters+Budget+Rating+Genre+Sequel+Production.Method+Opening)
anova(MLR2)
summary(MLR2)


## Equal variance meet due to flattness of line in first plot
plot(MLR2, 1)


## Normality meet due to diagonal line in qq plot and the large p-value in the shapiro-wilks test
plot(MLR2, 2)
shapiro.test(MLR2$residual)


## Linearity Check
par(mfrow=c(2,4))
plot(x = Theaters, y = MLR2$residual)
abline(h=0)
plot(x = Budget, y = MLR2$residual)
abline(h=0)
plot(x = Rating, y = MLR2$residual)
abline(h=0)
plot(x = Genre, y = MLR2$residual)
abline(h=0)
plot(x = Sequel, y = MLR2$residual)
abline(h=0)
plot(x = Production.Method, y = MLR2$residual)
abline(h=0)
plot(x = Opening, y = MLR2$residual)
abline(h=0)
## Linearity met due to randomness of every plot 


## Backward selection
step(MLR2, direction = "backward")


final<-lm(formula = lm.data$log.WorldRevenue ~ Theaters + Rating + Genre + 
            Production.Method + Opening)
summary(final)


